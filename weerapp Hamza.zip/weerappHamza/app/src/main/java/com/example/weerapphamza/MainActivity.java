package com.example.weerapphamza;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private final String API_KEY = "bc0aae60ca1ade77894c617fd6bee555"; // Je OpenWeatherMap API-sleutel

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verbind de EditText en Buttons uit de layout
        EditText etCity = findViewById(R.id.etCity);
        Button btnGetWeather = findViewById(R.id.btnGetWeather);
        TextView tvWeatherInfo = findViewById(R.id.tvWeatherInfo);

        // Stel de onClickListener in om weerinformatie op te halen
        btnGetWeather.setOnClickListener(v -> {
            String city = etCity.getText().toString();
            if (!city.isEmpty()) {
                getWeatherInfo(city, tvWeatherInfo);
            } else {
                tvWeatherInfo.setText("Voer een stad in.");
            }
        });
    }

    // Functie om het weer op te halen via de OpenWeatherMap API
    private void getWeatherInfo(String city, TextView tvWeatherInfo) {
        // URL voor de API-aanroep
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + API_KEY + "&units=metric";

        // Maak een requestqueue aan en haal de gegevens op met Volley
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        // Verwerk de JSON-response
                        JSONObject jsonObject = new JSONObject(response);
                        String temp = jsonObject.getJSONObject("main").getString("temp");
                        String description = jsonObject.getJSONArray("weather").getJSONObject(0).getString("description");

                        // Update de UI met de verkregen weersinformatie
                        tvWeatherInfo.setText("Temperatuur: " + temp + "°C\nBeschrijving: " + description);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        tvWeatherInfo.setText("Fout bij verwerken van gegevens.");
                    }
                },
                error -> tvWeatherInfo.setText("Fout bij ophalen van gegevens.")
        );

        // Voeg de request toe aan de queue
        queue.add(stringRequest);
    }
}
